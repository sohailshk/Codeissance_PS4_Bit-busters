# myproject/urls.py

from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.userprofile_list, name='userprofile_list'),
    path('scholarships/', views.scholarship_list, name='scholarship_list'),
    path('scholarships/add/', views.scholarship_create, name='scholarship_create'),
]
