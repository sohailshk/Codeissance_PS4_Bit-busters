from django import forms

class ScholarshipSearchForm(forms.Form):
    ACADEMIC_LEVEL_CHOICES = [
        ('undergraduate', 'Undergraduate'),
        ('postgraduate', 'Postgraduate'),
        ('phd', 'PhD'),
    ]

    FINANCIAL_BACKGROUND_CHOICES = [
        ('economically weak', 'Economically Weak'),
        ('middle class', 'Middle Class'),
        ('affluent', 'Affluent'),
    ]

    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]

    academic_level = forms.ChoiceField(choices=ACADEMIC_LEVEL_CHOICES)
    financial_background = forms.ChoiceField(choices=FINANCIAL_BACKGROUND_CHOICES)
    gender = forms.ChoiceField(choices=GENDER_CHOICES)
    field_of_study = forms.CharField(max_length=100)
