from django.contrib import admin
from .models import Scholarship

admin.site.register(Scholarship)
