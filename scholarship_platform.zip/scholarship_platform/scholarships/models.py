from django.db import models

class Scholarship(models.Model):
    ACADEMIC_LEVEL_CHOICES = [
        ('undergraduate', 'Undergraduate'),
        ('postgraduate', 'Postgraduate'),
        ('phd', 'PhD'),
    ]
    
    FINANCIAL_BACKGROUND_CHOICES = [
        ('economically weak', 'Economically Weak'),
        ('middle class', 'Middle Class'),
        ('affluent', 'Affluent'),
    ]
    
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]

    academic_level = models.CharField(max_length=20, choices=ACADEMIC_LEVEL_CHOICES)
    financial_background = models.CharField(max_length=20, choices=FINANCIAL_BACKGROUND_CHOICES)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    field_of_study = models.CharField(max_length=100)
    scholarship_name = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.scholarship_name} - {self.academic_level}"
