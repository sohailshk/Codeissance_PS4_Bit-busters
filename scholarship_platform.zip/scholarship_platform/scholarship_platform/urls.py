from django.urls import path, include
from django.contrib import admin

urlpatterns = [
    path('admin/', admin.site.urls),
    path('scholarships/', include('scholarships.urls')),  # Use the app name, not the full file path
]
